"""
Student Academic Performance Analysis and Early Risk Prediction
Based on the case study supplied by the student.

Expected input file: student_performance.csv
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    confusion_matrix, classification_report
)

RANDOM_STATE = 42
np.random.seed(RANDOM_STATE)
sns.set_theme(style="whitegrid")


def classify_risk(score):
    if score >= 70:
        return "Low Risk"
    elif score >= 50:
        return "Moderate Risk"
    return "High Risk"


def main():
    # 1. Load dataset
    df = pd.read_csv("student_performance.csv")
    print("\nDataset loaded successfully")
    print("Dataset shape:", df.shape)
    print("Columns:", df.columns.tolist())
    print("\nMissing values:")
    print(df.isnull().sum())
    print("\nFirst five records:")
    print(df.head())

    # 2. Clean data
    if "Student_ID" in df.columns:
        df = df.drop(columns=["Student_ID"])

    before = len(df)
    df = df.drop_duplicates()
    print("\nDuplicate records removed:", before - len(df))

    numeric_columns = [
        "Attendance", "Internal_Marks", "Assignment_Score",
        "Previous_Score", "Study_Hours", "Participation", "Final_Score"
    ]

    missing_columns = [c for c in numeric_columns if c not in df.columns]
    if missing_columns:
        raise ValueError(f"Missing required columns: {missing_columns}")

    for col in numeric_columns:
        df[col] = pd.to_numeric(df[col], errors="coerce")

    # Final_Score is the target source and is never imputed.
    df = df.dropna(subset=["Final_Score"])
    df[numeric_columns] = df[numeric_columns].fillna(df[numeric_columns].median())

    percent_columns = [
        "Attendance", "Internal_Marks", "Assignment_Score",
        "Previous_Score", "Final_Score"
    ]
    df[percent_columns] = df[percent_columns].clip(0, 100)
    df["Study_Hours"] = df["Study_Hours"].clip(0, 24)
    df["Participation"] = df["Participation"].clip(0, 10)

    print("Missing values after cleaning:", int(df.isnull().sum().sum()))
    print("Records available:", len(df))

    # 3. Exploratory Data Analysis
    print("\nDescriptive statistics:")
    print(df.describe().round(2))

    def plot_distribution(column, title, xlabel, filename):
        plt.figure(figsize=(8, 5))
        sns.histplot(df[column], kde=True)
        plt.title(title)
        plt.xlabel(xlabel)
        plt.ylabel("Number of Students")
        plt.tight_layout()
        plt.savefig(filename, dpi=200)
        plt.show()
        plt.close()

    plot_distribution(
        "Final_Score",
        "Distribution of Final Academic Scores",
        "Final Score",
        "final_score_distribution.png"
    )
    plot_distribution(
        "Attendance",
        "Distribution of Attendance",
        "Attendance (%)",
        "attendance_distribution.png"
    )
    plot_distribution(
        "Internal_Marks",
        "Distribution of Internal Marks",
        "Internal Marks",
        "internal_marks_distribution.png"
    )
    plot_distribution(
        "Assignment_Score",
        "Distribution of Assignment Scores",
        "Assignment Score",
        "assignment_distribution.png"
    )
    plot_distribution(
        "Previous_Score",
        "Distribution of Previous Scores",
        "Previous Score",
        "previous_score_distribution.png"
    )

    plt.figure(figsize=(9, 7))
    sns.heatmap(df[numeric_columns].corr(), annot=True, fmt=".2f", cmap="Blues")
    plt.title("Correlation Matrix of Academic Factors")
    plt.tight_layout()
    plt.savefig("correlation_matrix.png", dpi=200)
    plt.show()
    plt.close()

    relation_plots = [
        ("Attendance", "Attendance (%)"),
        ("Internal_Marks", "Internal Marks"),
        ("Study_Hours", "Study Hours per Day"),
        ("Previous_Score", "Previous Score"),
    ]

    for col, label in relation_plots:
        plt.figure(figsize=(8, 5))
        sns.regplot(
            x=df[col], y=df["Final_Score"],
            scatter_kws={"alpha": 0.5},
            line_kws={"color": "red"}
        )
        plt.title(f"{label} vs Final Score")
        plt.xlabel(label)
        plt.ylabel("Final Score")
        plt.tight_layout()
        plt.savefig(f"{col.lower()}_vs_final_score.png", dpi=200)
        plt.show()
        plt.close()

    # 4. Create risk target
    df["Academic_Risk"] = df["Final_Score"].apply(classify_risk)
    print("\nAcademic risk distribution:")
    print(df["Academic_Risk"].value_counts())
    print("\nRisk percentages:")
    print((df["Academic_Risk"].value_counts(normalize=True) * 100).round(2))

    # 5. Feature engineering
    df["Academic_Average"] = df[
        ["Internal_Marks", "Assignment_Score", "Previous_Score"]
    ].mean(axis=1)

    df["Engagement_Index"] = (
        df["Attendance"] + df["Participation"] * 10
    ) / 2

    features = [
        "Attendance", "Internal_Marks", "Assignment_Score",
        "Previous_Score", "Study_Hours", "Participation",
        "Academic_Average", "Engagement_Index"
    ]

    X = df[features]
    y = df["Academic_Risk"]

    # 6. Train-test split
    X_train, X_test, y_train, y_test = train_test_split(
        X, y,
        test_size=0.20,
        random_state=RANDOM_STATE,
        stratify=y
    )

    # 7. Scale without test-data leakage
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    # 8. Models
    models = {
        "Logistic Regression": LogisticRegression(
            max_iter=1000, random_state=RANDOM_STATE
        ),
        "Decision Tree": DecisionTreeClassifier(
            random_state=RANDOM_STATE, max_depth=5
        ),
        "Random Forest": RandomForestClassifier(
            n_estimators=100, random_state=RANDOM_STATE
        )
    }

    results = []
    trained_models = {}
    predictions = {}

    for name, model in models.items():
        model.fit(X_train_scaled, y_train)
        prediction = model.predict(X_test_scaled)
        predictions[name] = prediction
        trained_models[name] = model

        results.append({
            "Model": name,
            "Accuracy": accuracy_score(y_test, prediction),
            "Precision": precision_score(
                y_test, prediction, average="weighted", zero_division=0
            ),
            "Recall": recall_score(
                y_test, prediction, average="weighted", zero_division=0
            ),
            "F1-Score": f1_score(
                y_test, prediction, average="weighted", zero_division=0
            )
        })

    results_df = pd.DataFrame(results).sort_values(
        "F1-Score", ascending=False
    )
    print("\nModel Performance:")
    print(results_df.round(4).to_string(index=False))
    results_df.to_csv("model_performance.csv", index=False)

    # 9. Model comparison chart
    results_plot = results_df.set_index("Model")[
        ["Accuracy", "Precision", "Recall", "F1-Score"]
    ]
    results_plot.plot(kind="bar", figsize=(10, 6))
    plt.title("Model Performance Comparison")
    plt.ylabel("Score")
    plt.ylim(0, 1)
    plt.xticks(rotation=0)
    plt.tight_layout()
    plt.savefig("model_performance_comparison.png", dpi=200)
    plt.show()
    plt.close()

    # 10. Select best model by actual F1-score
    best_model_name = results_df.iloc[0]["Model"]
    best_model = trained_models[best_model_name]
    predicted_risk = best_model.predict(X_test_scaled)

    print("\nBest Model:", best_model_name)

    prediction_output = pd.DataFrame({
        "Actual_Risk": y_test.values,
        "Predicted_Risk": predicted_risk
    })
    print("\nFirst 10 predictions:")
    print(prediction_output.head(10).to_string(index=False))
    prediction_output.to_csv("prediction_output.csv", index=False)

    # 11. Confusion matrix
    labels = ["Low Risk", "Moderate Risk", "High Risk"]
    cm = confusion_matrix(y_test, predicted_risk, labels=labels)

    plt.figure(figsize=(7, 5))
    sns.heatmap(
        cm, annot=True, fmt="d", cmap="Blues",
        xticklabels=labels, yticklabels=labels
    )
    plt.title(f"Confusion Matrix - {best_model_name}")
    plt.xlabel("Predicted Risk")
    plt.ylabel("Actual Risk")
    plt.tight_layout()
    plt.savefig("confusion_matrix.png", dpi=200)
    plt.show()
    plt.close()

    print("\nClassification Report:")
    print(classification_report(
        y_test, predicted_risk, labels=labels, zero_division=0
    ))

    # 12. Risk distribution
    risk_counts = df["Academic_Risk"].value_counts().reindex(
        labels, fill_value=0
    )

    plt.figure(figsize=(8, 5))
    risk_counts.plot(kind="bar")
    plt.title("Student Academic Risk Distribution")
    plt.xlabel("Risk Category")
    plt.ylabel("Number of Students")
    plt.xticks(rotation=0)
    plt.tight_layout()
    plt.savefig("risk_distribution.png", dpi=200)
    plt.show()
    plt.close()

    # 13. Feature importance
    if hasattr(best_model, "feature_importances_"):
        importance = best_model.feature_importances_
    else:
        importance = np.abs(best_model.coef_).mean(axis=0)

    importance_series = pd.Series(
        importance, index=features
    ).sort_values(ascending=True)

    plt.figure(figsize=(8, 5))
    importance_series.plot(kind="barh")
    plt.title("Relative Importance of Academic Factors")
    plt.xlabel("Importance")
    plt.ylabel("Academic Factor")
    plt.tight_layout()
    plt.savefig("feature_importance.png", dpi=200)
    plt.show()
    plt.close()

    print("\nMost important academic factors:")
    print(importance_series.sort_values(ascending=False).round(4))

    print("\nProject execution completed successfully.")


if __name__ == "__main__":
    main()
